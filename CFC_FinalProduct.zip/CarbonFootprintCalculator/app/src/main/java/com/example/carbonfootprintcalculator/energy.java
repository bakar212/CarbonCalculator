package com.example.carbonfootprintcalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

import java.io.IOException;
import java.io.InputStream;
import java.util.Random;

public class energy extends AppCompatActivity {
    private EditText quest1 ;
    private EditText quest2;
    private Button next;
    private TextView factbox;

    public int getElectricoutput() {
        return electricoutput;
    }

    public  void setElectricoutput(int electricoutput) {
        energy.electricoutput = electricoutput;
    }

    public  int getGasoutput() {
        return gasoutput;
    }

    public  void setGasoutput(int gasoutput) {
        energy.gasoutput = gasoutput;
    }

    public static int electricoutput,gasoutput;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_energy);
        quest1 = findViewById(R.id.inputQuestion1);
        next = findViewById(R.id.nextButton);
        quest2 = findViewById(R.id.inputQuestion2);
        factbox = findViewById(R.id.factBox);
        energy act = new energy();
        Data data = new Data();

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {


                    int electrIcinput = Integer.parseInt(quest1.getText().toString());//variable that stores the user input from question 1
                    int gasInput = Integer.parseInt(quest2.getText().toString());//variable that stores the user input from question 2

                     setElectricoutput((int) (electrIcinput * 0.25319 * 12));
                    setGasoutput ((int) (gasInput * 0.18387 * 12));
                    Intent transportScreen = new Intent(energy.this, transport.class);
                    startActivity(transportScreen);


                }
                catch (Exception e){
                    Toast.makeText(energy.this, "Please Enter an Integer Number only", Toast.LENGTH_LONG).show();
                }

            }


        });
        String s = "";
        String[] sarr = new String[20];
        sarr[0] = "fact1.txt";
        sarr[1] = "fact2.txt";
        sarr[2] = "fact3.txt";
        sarr[3] = "fact4.txt";
        sarr[4] = "fact5.txt";
        sarr[5] = "fact6.txt";
        sarr[6] = "fact7.txt";
        sarr[7] = "fact8.txt";
        sarr[8] = "fact9.txt";
        sarr[9] = "fact10.txt";
        sarr[10] = "fact11.txt";
        sarr[11] = "fact12.txt";
        sarr[12] = "fact13.txt";
        sarr[13] = "fact14.txt";
        sarr[14] = "fact15.txt";
        sarr[15] = "fact16.txt";
        sarr[16] = "fact17.txt";
        sarr[17] = "fact18.txt";
        sarr[18] = "fact19.txt";
        sarr[19] = "fact20.txt";

        try {
            Random r = new Random();
            int randomint = r.nextInt(20);
            InputStream is = getAssets().open(sarr[randomint]);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            s = new String(buffer);

        }
        catch (IOException e) {

        }
        factbox.setText(s);

        }
}