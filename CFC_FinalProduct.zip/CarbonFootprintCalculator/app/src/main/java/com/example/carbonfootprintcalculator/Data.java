package com.example.carbonfootprintcalculator;

import java.text.DateFormat;
import java.util.Date;

public class Data {
    private String today;
    private int electric = 0;
    private int Gas = 0;
    private int transport = 0;
    private int flights = 0 ;
    private int food = 0 ;
    private int total = 0;

    public Data(String today,int electric, int gas, int transport, int flights, int food,int total) {
        this.today = today;
        this.electric = electric;
        Gas = gas;
        this.transport = transport;
        this.flights = flights;
        this.food = food;
        this.total = total;
    }
    public Data(){

    }

    @Override
    public String toString() {
        return "On " + today +
                " Your total emmissions was " + total + "\n" +
                "Your Breakdown is : " + "\n" +
                "Electricity = " + electric +
                ", Gas = " + Gas +
                ", Transport = " + transport +
                ", Food = " + food +
                ", Flights = " + flights
                ;
    }

    public int getElectric() {
        return electric;
    }

    public void setElectric(int electric) {
        this.electric = electric;
    }

    public void setDate() {
        Date current_date = new Date();
        String today_date = DateFormat.getDateInstance().format(current_date);
        today = today_date;
    }
    public String getDate() {
        return today;
    }

    public int getGas() {
        return Gas;
    }

    public void setGas(int gas) {
        Gas = gas;
    }

    public int getTransport() {
        return transport;
    }

    public void setTransport(int transport) {
        this.transport = transport;
    }

    public int getFlights() {
        return flights;
    }

    public void setFlights(int flights) {
        this.flights = flights;
    }

    public int getFood() {
        return food;
    }

    public void setFood(int food) {
        this.food = food;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public void calculatetotal(){
        int sum = getElectric()+getFlights()+getGas()+ getFood()+ getTransport();
        setTotal(sum);
    }
}
