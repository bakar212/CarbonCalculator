package com.example.carbonfootprintcalculator;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String CARBON_CALCULATOR = "Footprint_Calculator";
    public static final String MODE_OF_TRANSPORT = "ModeOfTransport";
    public static final String ELECTRICITY = "Electricity";
    public static final String FOOD = "Food";
    public static final String GAS = "Gas";
    public static final String TOTAL = "TOTAL";
    public static final String DATE = "DATE";
    public static final String FLIGHTS = "FLIGHTS";


    public DatabaseHelper(@Nullable Context context) {
        super(context, "footprint.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableStatement = "CREATE TABLE " + CARBON_CALCULATOR + "(ID INTEGER PRIMARY KEY AUTOINCREMENT, " + DATE + " TEXT, " + MODE_OF_TRANSPORT + " INT, " + ELECTRICITY + " INT, " + GAS + " INT, "  + FLIGHTS + " INT, "  + FOOD + " INT, " + TOTAL + " INT)";
        db.execSQL(createTableStatement);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public boolean addData(Data data){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DATE,data.getDate());
        cv.put(MODE_OF_TRANSPORT,data.getTransport());
        cv.put(ELECTRICITY,data.getElectric());
        cv.put(GAS,data.getGas());
        cv.put(FOOD,data.getFood());
        cv.put(FLIGHTS,data.getFlights());
        cv.put(TOTAL,data.getTotal());

        long insert =  db.insert(CARBON_CALCULATOR,null,cv);

        if(insert== -1){
            return false;
        }
        else {
            return true;
        }
    }

    public List<Data> getAll(){
        List<Data> returnAll = new ArrayList<>();
        String query = "SELECT * FROM "+ CARBON_CALCULATOR;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor =  db.rawQuery(query,null);
        if (cursor.moveToFirst()){

            do {
                int customer_ID = cursor.getInt(0);
                String date = cursor.getString(1);
                int transport = cursor.getInt(2);
                int elect = cursor.getInt(3);
                int gas =cursor.getInt(4);
                int flights =cursor.getInt(5);
                int food = cursor.getInt(6);
                int total =  cursor.getInt(7);

                Data dataa = new Data(date,elect,gas,transport,flights,food,total);
                returnAll.add(dataa);

            }
            while (cursor.moveToNext());
        }

        else {

        }
        cursor.close();
        db.close();
        return returnAll;
    }

}
