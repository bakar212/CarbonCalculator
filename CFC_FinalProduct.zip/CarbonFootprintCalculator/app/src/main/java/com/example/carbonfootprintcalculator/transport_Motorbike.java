package com.example.carbonfootprintcalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.util.Random;

public class transport_Motorbike extends AppCompatActivity implements AdapterView.OnItemSelectedListener  {
    Spinner dropdown;
    Button next;
    EditText motorInput;
    TextView factbox;

    public int getMotorEmmisions() {
        return motorEmmisions;
    }

    public void setMotorEmmisions(int motorEmmisions) {
        this.motorEmmisions = motorEmmisions;
    }

   public static int motorEmmisions = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_motorbike_transport);

        dropdown = findViewById(R.id.selectionMenu);
        next = findViewById(R.id.nextButton);
        motorInput = findViewById(R.id.motorInput);
        factbox = findViewById(R.id.factBox);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String selected = dropdown.getSelectedItem().toString();
                if (selected.equals("Select a Motorbike Size")) {
                    Toast.makeText(transport_Motorbike.this, "Please choose a valid option", Toast.LENGTH_LONG).show();

                } else {
                    try {
                        int motormiles =  Integer.parseInt(motorInput.getText().toString());
                        switch (selected) {
                            case "Small - Up to 125cc":
                               setMotorEmmisions((int) (motormiles * 0.08277));
                                break;
                            case "Medium - 125cc to 500cc":
                                setMotorEmmisions ((int) (motormiles * 0.10086));
                                break;
                            case "Large - Over 500cc":
                                setMotorEmmisions((int) (motormiles * 0.13237));
                                break;

                        }
                        Intent nextScreen = new Intent(transport_Motorbike.this, airTravel.class);
                        startActivity(nextScreen);

                    } catch (Exception e) {
                        Toast.makeText(transport_Motorbike.this, "Please Enter a number in KM", Toast.LENGTH_LONG).show();
                    }


                   // Toast.makeText(motorbike_transport.this, String.valueOf(motorEmmisions), Toast.LENGTH_LONG).show();

                }

            }
        });
        String s = "";
        String[] sarr = new String[20];
        sarr[0] = "fact1.txt";
        sarr[1] = "fact2.txt";
        sarr[2] = "fact3.txt";
        sarr[3] = "fact4.txt";
        sarr[4] = "fact5.txt";
        sarr[5] = "fact6.txt";
        sarr[6] = "fact7.txt";
        sarr[7] = "fact8.txt";
        sarr[8] = "fact9.txt";
        sarr[9] = "fact10.txt";
        sarr[10] = "fact11.txt";
        sarr[11] = "fact12.txt";
        sarr[12] = "fact13.txt";
        sarr[13] = "fact14.txt";
        sarr[14] = "fact15.txt";
        sarr[15] = "fact16.txt";
        sarr[16] = "fact17.txt";
        sarr[17] = "fact18.txt";
        sarr[18] = "fact19.txt";
        sarr[19] = "fact20.txt";

        try {
            Random r = new Random();
            int randomint = r.nextInt(20);
            InputStream is = getAssets().open(sarr[randomint]);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            s = new String(buffer);

        }
        catch (IOException e) {

        }
        factbox.setText(s);




    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}