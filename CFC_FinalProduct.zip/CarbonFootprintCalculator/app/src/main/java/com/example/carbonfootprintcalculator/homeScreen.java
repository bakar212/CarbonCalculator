package com.example.carbonfootprintcalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class homeScreen extends AppCompatActivity {

    private Button start;
    private Button VeiwAll;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homescreen);
        start = findViewById(R.id.startButton);
        VeiwAll = findViewById(R.id.scoreButton);


        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent nextScreen = new Intent(homeScreen.this, energy.class);
                startActivity(nextScreen);
            }
        });

        VeiwAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent scoreScreen = new Intent(homeScreen.this,VeiwScores.class);
                startActivity(scoreScreen);

            }
        });





    }
}