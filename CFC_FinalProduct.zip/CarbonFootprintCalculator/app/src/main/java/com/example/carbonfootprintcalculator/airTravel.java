package com.example.carbonfootprintcalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.util.Random;

public class airTravel extends AppCompatActivity {
    Button next;
    EditText neutralInput;
    TextView factbox;

    public int getNeutralEmission() {
        return neutralEmission;
    }

    public void setNeutralEmission(int neutralEmission) {
        this.neutralEmission = neutralEmission;
    }

    public static int neutralEmission ;
    RadioButton first, second, third, forth, selectedRadioButton;
    RadioGroup radioGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_airtravel);
        first    = findViewById(R.id.radioButton);
        second = findViewById(R.id.radioButton2);
        third = findViewById(R.id.radioButton3);
        forth = findViewById(R.id.radioButton4);
        radioGroup = findViewById(R.id.airTravelFreq);
        next = findViewById(R.id.nextButton);
        neutralInput = findViewById(R.id.inputQuest);
        factbox = findViewById(R.id.factBox);


        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (radioGroup.getCheckedRadioButtonId() == -1)
                {
                    // no radio buttons are checked
                    Toast.makeText(airTravel.this, "Please choose a valid option", Toast.LENGTH_LONG).show();
                }
                else
                {
                    // one of the radio buttons is checked
                    // get selected radio button from radioGroup
                    int selectedId = radioGroup.getCheckedRadioButtonId();
                    // find the radiobutton by returned id
                    selectedRadioButton = (RadioButton)findViewById(selectedId);
                    String selected = selectedRadioButton.getText().toString();
                    try {
                        int neutralMiles =  Integer.parseInt(neutralInput.getText().toString());
                        switch (selected) {
                            case "0":
                                setNeutralEmission ((int) (neutralMiles * 0));
                                Intent scoreScreen = new Intent(airTravel.this,VeiwScores.class);
                                startActivity(scoreScreen);
                                break;
                            case "1-3":
                              setNeutralEmission ((int) (neutralMiles * 0.1753*2));
                                Intent scoreScreen1 = new Intent(airTravel.this,VeiwScores.class);
                                startActivity(scoreScreen1);
                                break;
                            case "4-6":
                                setNeutralEmission((int) (neutralMiles * 0.1753*5));
                                Intent scoreScreen2 = new Intent(airTravel.this,VeiwScores.class);
                                startActivity(scoreScreen2);
                                break;
                            case "7+":
                                setNeutralEmission ((int) (neutralMiles * 0.1753*7));
                                Intent scoreScreen3 = new Intent(airTravel.this,VeiwScores.class);
                                startActivity(scoreScreen3);
                                break;

                        }
                        Intent nextScreen = new Intent(airTravel.this,food.class);
                        startActivity(nextScreen);

                    } catch (Exception e) {
                        Toast.makeText(airTravel.this, "Please Enter a number in KM", Toast.LENGTH_LONG).show();
                    }
                }
            }

        });
        String s = "";
        String[] sarr = new String[20];
        sarr[0] = "fact1.txt";
        sarr[1] = "fact2.txt";
        sarr[2] = "fact3.txt";
        sarr[3] = "fact4.txt";
        sarr[4] = "fact5.txt";
        sarr[5] = "fact6.txt";
        sarr[6] = "fact7.txt";
        sarr[7] = "fact8.txt";
        sarr[8] = "fact9.txt";
        sarr[9] = "fact10.txt";
        sarr[10] = "fact11.txt";
        sarr[11] = "fact12.txt";
        sarr[12] = "fact13.txt";
        sarr[13] = "fact14.txt";
        sarr[14] = "fact15.txt";
        sarr[15] = "fact16.txt";
        sarr[16] = "fact17.txt";
        sarr[17] = "fact18.txt";
        sarr[18] = "fact19.txt";
        sarr[19] = "fact20.txt";

        try {
            Random r = new Random();
            int randomint = r.nextInt(20);
            InputStream is = getAssets().open(sarr[randomint]);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            s = new String(buffer);

        }
        catch (IOException e) {

        }
        factbox.setText(s);

    }
}