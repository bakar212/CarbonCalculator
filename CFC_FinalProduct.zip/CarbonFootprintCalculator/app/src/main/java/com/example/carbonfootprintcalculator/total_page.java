package com.example.carbonfootprintcalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import lecho.lib.hellocharts.model.PieChartData;
import lecho.lib.hellocharts.model.SliceValue;
import lecho.lib.hellocharts.view.PieChartView;

public class total_page extends AppCompatActivity {
    PieChartView pie;
    TextView text;
    int avg ;
    Button share,finish;
    Data data = new Data();
    energy main_act = new energy();
    transport_Car car = new transport_Car();
    transport_Motorbike motorbike = new transport_Motorbike();
    transport_PublicTransport public_transport = new transport_PublicTransport();
    airTravel plane = new airTravel();
    food food_1 = new food();
    int electricity, gas, diet, totaltransport;
    int flights;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_total_page);
        text = findViewById(R.id.factBox);
        finish = findViewById(R.id.finishButton);
        share = findViewById(R.id.shareButton);
        totaltransport = car.getCarEmmisions() + motorbike.getMotorEmmisions() + public_transport.getPublicEmission();
        flights = plane.getNeutralEmission();
        electricity = main_act.getElectricoutput();

        gas = main_act.getGasoutput();
        diet = food_1.getFoodEmmisions();
        data.setDate();
        data.setFlights(flights);
        data.setElectric(electricity);
        data.setGas(gas);
        data.setTransport(totaltransport);
        data.setFood(diet);
        data.calculatetotal();
        DatabaseHelper databaseHelper = new DatabaseHelper(total_page.this);
        boolean success = databaseHelper.addData(data);


        avg = 8340 - data.getTotal();



        if(avg >0){
            text.setText("You save " + avg + " kg's more than the average UK citizen");
        }
        else if(avg<0){
            text.setText("You use " + (avg*-1) + " kg's more than the average UK citizen");
        }

        pie = findViewById(R.id.chart);


        List<SliceValue> pieData = new ArrayList<>();

        pieData.add(new SliceValue(electricity, Color.BLUE).setLabel("Electricity: " + String.valueOf(electricity) + " Kg's"));
        pieData.add(new SliceValue(gas, Color.GRAY).setLabel("Gas " + String.valueOf(gas) + " Kg's"));
        pieData.add(new SliceValue(totaltransport,Color.RED).setLabel("Transport " + String.valueOf(totaltransport) + " Kg's"));
        pieData.add(new SliceValue(diet,Color.MAGENTA).setLabel("Food " + String.valueOf(diet) + " Kg's"));
        pieData.add(new SliceValue(flights,Color.YELLOW).setLabel("Flights " + String.valueOf(flights) + " Kg's"));

        PieChartData pieChartData = new PieChartData(pieData);
        pieChartData.setHasLabels(true);
        pieChartData.setHasCenterCircle(true).setCenterText1("Total Emmisions / Year:" + String.valueOf(data.getTotal()) + " Kg's").setCenterText1FontSize(12).setCenterText1Color(Color.parseColor("#FF0000"));

        pie.setPieChartData(pieChartData);

        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT, "Hey Check out my Carbon Footprint Score : I emit " + data.getTotal()+ " Kg's of carbon a year!");
                sendIntent.setType("text/plain");

                Intent shareIntent = Intent.createChooser(sendIntent, null);
                startActivity(shareIntent);
            }
        });

        finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextScreen = new Intent(total_page.this, homeScreen.class);
                startActivity(nextScreen);
            }
        });

    }
}